function search() {
	var input;
	input = document.getElementById('searchInput');
	console.log(input)
}
