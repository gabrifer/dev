$(document).ready(function() {
  generateSlide()
})
